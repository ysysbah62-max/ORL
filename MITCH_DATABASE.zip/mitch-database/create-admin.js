require("dotenv").config();
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const path = require("path");
const fs = require("fs");

const username = process.argv[2];
const password = process.argv[3];
if (!username || !password) {
  console.error('Usage: npm run create-admin -- adminname "A-Long-Unique-Password"');
  process.exit(1);
}
if (!/^[a-zA-Z0-9_.-]{3,32}$/.test(username) || password.length < 12 || password.length > 200) {
  console.error("Username must be 3-32 safe characters; password must be 12-200 characters.");
  process.exit(1);
}
const dbPath = path.resolve(process.env.DB_PATH || "./data/private.sqlite");
fs.mkdirSync(path.dirname(dbPath), { recursive: true, mode: 0o700 });
const db = new Database(dbPath);
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('admin','user')) DEFAULT 'user',
 active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS records (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 owner_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
 title TEXT NOT NULL,
 content TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS audit_logs (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 actor_id INTEGER,
 action TEXT NOT NULL,
 target TEXT,
 ip TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);
const hash = bcrypt.hashSync(password, 12);
try {
  db.prepare("INSERT INTO users(username,password_hash,role) VALUES(?,?,'admin')").run(username, hash);
  console.log("Admin account created. Save your credentials securely.");
} catch (e) {
  if (String(e.code).includes("SQLITE_CONSTRAINT")) console.error("That username already exists.");
  else throw e;
  process.exitCode = 1;
}
db.close();
