require("dotenv").config();
const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");
const fs = require("fs");

const app = express();
const HOST = process.env.HOST || "127.0.0.1";
const PORT = Number(process.env.PORT || 3080);
const DB_PATH = path.resolve(process.env.DB_PATH || "./data/private.sqlite");
const SESSION_DB_PATH = path.resolve(process.env.SESSION_DB_PATH || "./data/sessions.sqlite");
const SESSION_SECRET = process.env.SESSION_SECRET || "";

if (SESSION_SECRET.length < 32) {
  console.error("ERROR: Set SESSION_SECRET in .env to a random value of at least 32 characters.");
  process.exit(1);
}
if (process.env.NODE_ENV === "production" && HOST === "0.0.0.0" && process.env.TRUST_PROXY !== "1") {
  console.warn("WARNING: Public binding detected. Put this app behind HTTPS and a trusted reverse proxy.");
}
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true, mode: 0o700 });
fs.mkdirSync(path.dirname(SESSION_DB_PATH), { recursive: true, mode: 0o700 });

const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.pragma("busy_timeout = 5000");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('admin','user')) DEFAULT 'user',
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_id INTEGER,
  action TEXT NOT NULL,
  target TEXT,
  ip TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_records_owner ON records(owner_id);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at);
`);

if (process.env.TRUST_PROXY === "1") app.set("trust proxy", 1);
app.disable("x-powered-by");
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"],
      upgradeInsecureRequests: process.env.NODE_ENV === "production" ? [] : null
    }
  },
  crossOriginEmbedderPolicy: false
}));
app.use(express.json({ limit: "32kb" }));
app.use(express.urlencoded({ extended: false, limit: "8kb" }));

app.use(session({
  name: "mitch.sid",
  store: new SQLiteStore({ db: path.basename(SESSION_DB_PATH), dir: path.dirname(SESSION_DB_PATH), table: "sessions" }),
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  rolling: true,
  cookie: {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    maxAge: 1000 * 60 * 60 * 4
  }
}));

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 8,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "محاولات كثيرة. حاول بعد 15 دقيقة." }
});
const writeLimiter = rateLimit({ windowMs: 60 * 1000, limit: 60, standardHeaders: "draft-7", legacyHeaders: false });

function audit(req, action, target = "") {
  db.prepare("INSERT INTO audit_logs(actor_id, action, target, ip) VALUES(?,?,?,?)")
    .run(req.session.user?.id || null, action, String(target).slice(0, 160), req.ip || "");
}
function requireAuth(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "يلزم تسجيل الدخول." });
  const current = db.prepare("SELECT id, username, role, active FROM users WHERE id = ?").get(req.session.user.id);
  if (!current || !current.active) {
    return req.session.destroy(() => res.status(401).json({ error: "الحساب غير فعال." }));
  }
  req.user = current;
  next();
}
function requireAdmin(req, res, next) {
  if (req.user?.role !== "admin") return res.status(403).json({ error: "هذه العملية للمدير فقط." });
  next();
}
function sameOrigin(req, res, next) {
  if (!["POST", "PUT", "PATCH", "DELETE"].includes(req.method)) return next();
  const origin = req.get("origin");
  if (!origin) return res.status(403).json({ error: "طلب مرفوض." });
  try {
    const expected = `${req.protocol}://${req.get("host")}`;
    if (new URL(origin).origin !== expected) return res.status(403).json({ error: "مصدر الطلب غير مسموح." });
  } catch { return res.status(403).json({ error: "مصدر الطلب غير صالح." }); }
  next();
}
app.use("/api", sameOrigin);
app.use("/api", writeLimiter);

app.get("/api/csrf", (req, res) => {
  // Same-origin + SameSite strict + HttpOnly session cookie protect browser requests.
  res.set("Cache-Control", "no-store").json({ ok: true });
});
app.post("/api/login", loginLimiter, (req, res, next) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  if (!username || !password || username.length > 64 || password.length > 200) {
    return res.status(400).json({ error: "أدخل اسم المستخدم وكلمة المرور." });
  }
  const user = db.prepare("SELECT id, username, password_hash, role, active FROM users WHERE username = ?").get(username);
  if (!user || !user.active || !bcrypt.compareSync(password, user.password_hash)) {
    audit(req, "login_failed", username);
    return res.status(401).json({ error: "بيانات الدخول غير صحيحة." });
  }
  req.session.regenerate(err => {
    if (err) return next(err);
    req.session.user = { id: user.id };
    audit(req, "login_success", user.username);
    res.json({ ok: true, user: { id: user.id, username: user.username, role: user.role } });
  });
});
app.post("/api/logout", requireAuth, (req, res) => {
  audit(req, "logout", req.user.username);
  req.session.destroy(() => {
    res.clearCookie("mitch.sid", { httpOnly: true, sameSite: "strict", secure: process.env.NODE_ENV === "production" });
    res.json({ ok: true });
  });
});
app.get("/api/me", requireAuth, (req, res) => res.set("Cache-Control", "no-store").json({ user: req.user }));

app.get("/api/records", requireAuth, (req, res) => {
  const rows = req.user.role === "admin"
    ? db.prepare("SELECT id, owner_id, title, content, created_at, updated_at FROM records ORDER BY id DESC").all()
    : db.prepare("SELECT id, owner_id, title, content, created_at, updated_at FROM records WHERE owner_id = ? ORDER BY id DESC").all(req.user.id);
  res.set("Cache-Control", "no-store").json({ records: rows });
});
app.post("/api/records", requireAuth, (req, res) => {
  const title = String(req.body.title || "").trim();
  const content = String(req.body.content || "");
  if (!title || title.length > 120 || content.length > 10000) return res.status(400).json({ error: "العنوان مطلوب (120 حرفاً كحد أقصى) والمحتوى حتى 10000 حرف." });
  const info = db.prepare("INSERT INTO records(owner_id,title,content) VALUES(?,?,?)").run(req.user.id, title, content);
  audit(req, "record_created", info.lastInsertRowid);
  res.status(201).json({ ok: true, id: info.lastInsertRowid });
});
app.put("/api/records/:id", requireAuth, (req, res) => {
  const id = Number(req.params.id);
  const title = String(req.body.title || "").trim();
  const content = String(req.body.content || "");
  if (!Number.isSafeInteger(id) || !title || title.length > 120 || content.length > 10000) return res.status(400).json({ error: "بيانات غير صالحة." });
  const row = db.prepare("SELECT id, owner_id FROM records WHERE id = ?").get(id);
  if (!row) return res.status(404).json({ error: "السجل غير موجود." });
  if (req.user.role !== "admin" && row.owner_id !== req.user.id) return res.status(403).json({ error: "غير مصرح." });
  db.prepare("UPDATE records SET title=?, content=?, updated_at=CURRENT_TIMESTAMP WHERE id=?").run(title, content, id);
  audit(req, "record_updated", id);
  res.json({ ok: true });
});
app.delete("/api/records/:id", requireAuth, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id)) return res.status(400).json({ error: "معرّف غير صالح." });
  const row = db.prepare("SELECT id, owner_id FROM records WHERE id = ?").get(id);
  if (!row) return res.status(404).json({ error: "السجل غير موجود." });
  if (req.user.role !== "admin" && row.owner_id !== req.user.id) return res.status(403).json({ error: "غير مصرح." });
  db.prepare("DELETE FROM records WHERE id=?").run(id);
  audit(req, "record_deleted", id);
  res.json({ ok: true });
});

app.get("/api/admin/summary", requireAuth, requireAdmin, (req, res) => {
  res.json({
    users: db.prepare("SELECT COUNT(*) AS n FROM users").get().n,
    records: db.prepare("SELECT COUNT(*) AS n FROM records").get().n,
    logs: db.prepare("SELECT COUNT(*) AS n FROM audit_logs").get().n
  });
});
app.get("/api/admin/users", requireAuth, requireAdmin, (req, res) => {
  const users = db.prepare("SELECT id, username, role, active, created_at FROM users ORDER BY id DESC").all();
  res.json({ users });
});
app.post("/api/admin/users", requireAuth, requireAdmin, (req, res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  const role = req.body.role === "admin" ? "admin" : "user";
  if (!/^[a-zA-Z0-9_.-]{3,32}$/.test(username) || password.length < 12 || password.length > 200) {
    return res.status(400).json({ error: "اسم المستخدم 3-32 حرفاً إنجليزيّاً/أرقاماً. كلمة المرور 12 حرفاً على الأقل." });
  }
  try {
    const hash = bcrypt.hashSync(password, 12);
    const info = db.prepare("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)").run(username, hash, role);
    audit(req, "user_created", username);
    res.status(201).json({ ok: true, id: info.lastInsertRowid });
  } catch (e) {
    if (String(e.code).includes("SQLITE_CONSTRAINT")) return res.status(409).json({ error: "اسم المستخدم مستخدم مسبقاً." });
    throw e;
  }
});
app.patch("/api/admin/users/:id", requireAuth, requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id === req.user.id) return res.status(400).json({ error: "لا يمكن تعديل هذا الحساب." });
  const active = req.body.active === false ? 0 : 1;
  const role = req.body.role === "admin" ? "admin" : "user";
  const result = db.prepare("UPDATE users SET active=?, role=? WHERE id=?").run(active, role, id);
  if (!result.changes) return res.status(404).json({ error: "المستخدم غير موجود." });
  audit(req, "user_updated", id);
  res.json({ ok: true });
});
app.get("/api/admin/logs", requireAuth, requireAdmin, (req, res) => {
  const logs = db.prepare("SELECT id, actor_id, action, target, ip, created_at FROM audit_logs ORDER BY id DESC LIMIT 200").all();
  res.json({ logs });
});

// Never expose the SQLite files or environment configuration through static hosting.
app.use(express.static(path.join(__dirname, "public"), { dotfiles: "deny", index: "index.html", maxAge: process.env.NODE_ENV === "production" ? "1h" : 0 }));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.use((err, req, res, next) => {
  console.error(err);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: "حدث خطأ داخلي. راجع سجل الخادم." });
});

app.listen(PORT, HOST, () => console.log(`MITCH DATABASE running at http://${HOST}:${PORT}`));
